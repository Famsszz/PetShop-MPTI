<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    // public function up()
    // {
    //     DB::unprepared('
        
    //     CREATE TRIGGER after_booking_insert AFTER INSERT ON `booking` FOR EACH ROW
    //     BEGIN
    //         INSERT INTO log_booking (ID_Booking, ID_Pengguna, Action, Tanggal_New, Jam_New, Diperbarui)
    //         VALUES (NEW.ID_Booking, NEW.ID_Pengguna, "INSERT", NEW.Tanggal, NEW.Jam, CURRENT_TIMESTAMP);
    //     END;


    //     ');

    //     DB::unprepared('
        
    //     CREATE TRIGGER after_booking_update AFTER UPDATE ON `booking` FOR EACH ROW
    //     BEGIN
    //         INSERT INTO log_booking (ID_Booking, ID_Pengguna, Action, Tanggal_Old, Tanggal_New, Jam_Old, Jam_New, Diperbarui)
    //         VALUES (OLD.ID_Booking, OLD.ID_Pengguna, "UPDATE", OLD.Tanggal, NEW.Tanggal, OLD.Jam, NEW.Jam, CURRENT_TIMESTAMP);
    //     END;


    //     ');

    //     DB::unprepared('
    //     CREATE TRIGGER after_booking_delete AFTER DELETE ON `booking` FOR EACH ROW
    //     BEGIN
    //         INSERT INTO log_booking (ID_Booking, ID_Pengguna, Action, Tanggal_Old, Jam_Old, Diperbarui)
    //         VALUES (OLD.ID_Booking, OLD.ID_Pengguna, "DELETE", OLD.Tanggal, OLD.Jam, CURRENT_TIMESTAMP);
    //     END;

    //     ');
       

    // }
    public function down()
    {
        //
    }
};
