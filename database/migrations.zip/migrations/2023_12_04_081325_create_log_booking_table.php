<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('log_booking', function (Blueprint $table) {
            $table->integer('ID_Booking')->nullable();
            $table->integer('ID_Penitipan')->nullable();
            $table->integer('ID_Pengguna')->nullable();
            $table->string('Action')->nullable();
            $table->date('Tanggal_Old')->nullable();
            $table->date('Tanggal_New')->nullable();
            $table->time('Jam_Old')->nullable();
            $table->time('Jam_New')->nullable();
            $table->timestamp('Diperbarui')->useCurrent();
        });
    }

    public function down()
    {
        Schema::dropIfExists('log_booking');
    }
};
